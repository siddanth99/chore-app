-- AlterTable
ALTER TABLE "chores" ADD COLUMN     "imageUrl" TEXT;
